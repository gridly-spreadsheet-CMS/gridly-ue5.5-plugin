﻿// Copyright (c) 2021 LocalizeDirect AB

#pragma once

#include "GridlyResult.h"

const FGridlyResult FGridlyResult::Success;
